# ChatBot
chatbot in python using chatterbot module and chatterbot corpus for data training.
